import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Header */}
      <header className="bg-[#001f3f] py-6 px-4 sm:px-8 lg:px-12">
        <h1 className="font-bold text-3xl sm:text-4xl">Home</h1>
        <nav className="mt-4 flex flex-wrap gap-4">
          <a
            href="/admin"
            className="text-[#5c6367] hover:text-white transition-colors duration-200"
          >
            Administration
          </a>
          <a
            href="/inspection"
            className="text-[#5c6367] hover:text-white transition-colors duration-200"
          >
            Inspection
          </a>
          <a
            href="/testing"
            className="text-[#5c6367] hover:text-white transition-colors duration-200"
          >
            Testing
          </a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="flex flex-col md:flex-row items-center justify-between gap-8 lg:gap-16 py-12 px-6 sm:px-12 lg:px-20">
        <div className="md:w-1/2">
          <h2 className="font-bold text-2xl sm:text-3xl mb-4">
            Empowering Military & Technical Operations
          </h2>
          <p className="text-lg sm:text-xl text-[#5c6367]">
            Our platform delivers streamlined navigation and powerful data
            insights for administration, inspection, and testing workflows. 
            Designed with a bold navy core, military gray accents, and a
            strategic black backdrop to reinforce professionalism and 
            technological precision.
          </p>
        </div>
        <div className="md:w-1/2 flex justify-center">
          <img
            src="https://via.placeholder.com/500x300"
            alt="Technology in action"
            className="rounded-md shadow-xl w-full object-cover"
          />
        </div>
      </section>

      {/* Quick Links Section */}
      <section className="bg-[#001f3f] py-10 px-6 sm:px-12 lg:px-20">
        <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
          <div>
            <h3 className="font-semibold text-xl mb-2">Administration</h3>
            <p className="text-[#5c6367]">
              Manage users, roles, and system settings with ease.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-xl mb-2">Inspection</h3>
            <p className="text-[#5c6367]">
              Conduct thorough reviews and compliance checks.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-xl mb-2">Testing</h3>
            <p className="text-[#5c6367]">
              Execute rigorous test suites across environments.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#001f3f] py-4 px-6 sm:px-12 lg:px-20 text-center text-[#5c6367] text-sm">
        © {new Date().getFullYear()} Military Tech Suite. All rights reserved.
      </footer>
    </div>
  );
}