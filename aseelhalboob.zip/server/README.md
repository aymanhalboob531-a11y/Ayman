# Backend

Generated stub for military-inspection-admin. Run with `node server/index.js` after wiring an Express server.