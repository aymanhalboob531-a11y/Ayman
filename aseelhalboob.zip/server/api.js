const express = require('express');
const router = express.Router();

// In‑memory mock data for inspectors
let inspectors = [
  { id: 1, fullName: 'Ahmed Ali', militaryId: 'A001', rank: 'Major', isAdmin: true },
  { id: 2, fullName: 'Fatima Hassan', militaryId: 'A002', rank: 'Captain', isAdmin: false }
];

// GET /api/inspectors
// Retrieve the list of authorized inspectors
router.get('/api/inspectors', (req, res) => {
  res.json(inspectors);
});

// POST /api/inspectors
// Add a new inspector to the in‑memory database
router.post('/api/inspectors', (req, res) => {
  const { fullName, militaryId, rank, isAdmin } = req.body;
  if (!fullName || !militaryId || !rank) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  const newId = inspectors.length ? Math.max(...inspectors.map(i => i.id)) + 1 : 1;
  const newInspector = {
    id: newId,
    fullName,
    militaryId,
    rank,
    isAdmin: !!isAdmin
  };
  inspectors.push(newInspector);
  res.status(201).json(newInspector);
});

// PUT /api/inspectors/:id
// Update an existing inspector's details
router.put('/api/inspectors/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const inspector = inspectors.find(i => i.id === id);
  if (!inspector) {
    return res.status(404).json({ error: 'Inspector not found' });
  }

  const { fullName, militaryId, rank, isAdmin } = req.body;
  if (fullName !== undefined) inspector.fullName = fullName;
  if (militaryId !== undefined) inspector.militaryId = militaryId;
  if (rank !== undefined) inspector.rank = rank;
  if (isAdmin !== undefined) inspector.isAdmin = !!isAdmin;

  res.json(inspector);
});

// DELETE /api/inspectors/:id
// Remove an inspector from the in‑memory database
router.delete('/api/inspectors/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const index = inspectors.findIndex(i => i.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Inspector not found' });
  }
  inspectors.splice(index, 1);
  res.status(204).end();
});

module.exports = router;